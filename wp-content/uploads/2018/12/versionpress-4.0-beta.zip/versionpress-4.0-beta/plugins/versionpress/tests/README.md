# VersionPress tests

See [Dev-Setup.md#testing](../../../docs/Dev-Setup.md#testing).
