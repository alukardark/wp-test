Visit https://github.com/versionpress/support first please, or chat with us on Gitter.

Good issue contains:

- Clear description
- An example, screenshot or GIF
- Info about the environment (VP and WP version, OS etc.) if relevant

Thanks!
